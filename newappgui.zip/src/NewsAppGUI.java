import com.google.gson.Gson;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class NewsAppGUI extends JFrame {
    // UI Components
    private JComboBox<String> categoryComboBox;
    private JTextField searchTextField;
    private JButton searchButton;
    private JList<String> articlesList;
    private DefaultListModel<String> listModel;

    private static List<NewsArticle> articles = new ArrayList<>();
    private static NewsAppGUI instance;

    // Singleton Pattern - Ensures only one instance of NewsAppGUI
    private NewsAppGUI() {
        setTitle("News App");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // UI Components
        categoryComboBox = new JComboBox<>(new String[]{"All", "Politics", "Technology"});
        searchTextField = new JTextField(20);
        searchButton = new JButton("Search");
        listModel = new DefaultListModel<>();
        articlesList = new JList<>(listModel);

        // Layout
        setLayout(new BorderLayout());
        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Select Category:"));
        topPanel.add(categoryComboBox);
        topPanel.add(new JLabel("Search:"));
        topPanel.add(searchTextField);
        topPanel.add(searchButton);
        add(topPanel, BorderLayout.NORTH);
        add(new JScrollPane(articlesList), BorderLayout.CENTER);

        // Initialize articles and preferences
        try {
            initializeArticles(); // Fetch articles using Factory Pattern
            loadUserPreferences(); // Load user preferences using Adapter Pattern
            updateArticleList(articles);
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Action listener for search
        searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String searchText = searchTextField.getText().trim();
                List<NewsArticle> filteredArticles = searchArticles(searchText);
                updateArticleList(filteredArticles);
            }
        });
    }

    // Singleton Pattern to get the instance
    public static NewsAppGUI getInstance() {
        if (instance == null) {
            instance = new NewsAppGUI();
        }
        return instance;
    }

    // Method to initialize articles by fetching data from NewsAPI (Factory Pattern)
    public void initializeArticles() throws Exception {
        String apiKey = "0f2e28bd6891428a8586366a06f97f55"; // Use your actual API key
        String urlString = "https://newsapi.org/v2/top-headlines?country=us&pageSize=100&apiKey=" + apiKey;

        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(5000);
        connection.setReadTimeout(5000);

        int status = connection.getResponseCode();
        if (status == HttpURLConnection.HTTP_OK) {
            BufferedReader in = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String inputLine;
            StringBuffer response = new StringBuffer();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            // Parse the JSON response using Gson
            Gson gson = new Gson();
            NewsApiResponse newsApiResponse = gson.fromJson(response.toString(), NewsApiResponse.class);

            // Use Factory Pattern to create NewsArticle objects
            for (NewsArticleResponse articleResponse : newsApiResponse.articles) {
                NewsArticle article = NewsArticleFactory.createArticle(articleResponse);
                if (article != null) {
                    articles.add(article);
                }
            }
        } else {
            throw new Exception("Error fetching news from API");
        }
    }

    // Method to search for articles based on the searchText
    public List<NewsArticle> searchArticles(String searchText) {
        if (searchText == null || searchText.trim().isEmpty()) {
            return articles; // Return all articles if search text is empty
        }

        // Filter articles based on search text
        return articles.stream()
                .filter(article -> article.getTitle() != null && article.getContent() != null &&
                        (article.getTitle().toLowerCase().contains(searchText.toLowerCase()) ||
                                article.getContent().toLowerCase().contains(searchText.toLowerCase())))
                .collect(Collectors.toList());
    }

    // Update the list with filtered articles
    private void updateArticleList(List<NewsArticle> articles) {
        listModel.clear();
        for (NewsArticle article : articles) {
            listModel.addElement(article.getTitle()); // Show only titles
        }
    }

    // Load user preferences from the database (Adapter Pattern)
    private void loadUserPreferences() {
        String url = "jdbc:sqlserver://laptop-0mjvllan\\SQLEXPRESS:1433;databaseName=NewsApp;integratedSecurity=true;";
        try (Connection connection = DriverManager.getConnection(url)) {
    System.out.println("Connection to the database was successful!");
} catch (SQLException e) {
    e.printStackTrace();
}
 // Database connection URL
        String user = ""; // Use Windows Authentication
        String password = ""; // Empty for Windows Authentication

        try (Connection connection = DriverManager.getConnection(url, user, password)) {
            String query = "SELECT Category FROM UserPreferences WHERE Id = 1"; // Assume we're retrieving preferences for a user with Id=1
            Statement stmt = connection.createStatement();
            ResultSet rs = stmt.executeQuery(query);

            UserPreferencesAdapter adapter = new UserPreferencesAdapter(rs);
            String category = adapter.getCategory();
            if (category != null && !category.isEmpty()) {
                categoryComboBox.setSelectedItem(category);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Main method
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                NewsAppGUI app = NewsAppGUI.getInstance();
                app.setVisible(true);
            }
        });
    }

    // News Article class with Builder and Prototype Patterns
    public static class NewsArticle implements Cloneable {
        private String title;
        private String description;
        private String author;
        private String urlToImage;
        private String source;

        // Private constructor for Builder Pattern
        private NewsArticle(NewsArticleBuilder builder) {
            this.title = builder.title;
            this.description = builder.description;
            this.author = builder.author;
            this.urlToImage = builder.urlToImage;
            this.source = builder.source;
        }

        public String getTitle() {
            return title;
        }

        public String getDescription() {
            return description;
        }

        public String getContent() {
            return description; // In this case, we use description as content
        }

        @Override
        public NewsArticle clone() {
            try {
                return (NewsArticle) super.clone();
            } catch (CloneNotSupportedException e) {
                throw new AssertionError();
            }
        }

        // Builder Pattern for constructing NewsArticle objects
        public static class NewsArticleBuilder {
            private String title;
            private String description;
            private String author;
            private String urlToImage;
            private String source;

            public NewsArticleBuilder setTitle(String title) {
                this.title = title;
                return this;
            }

            public NewsArticleBuilder setDescription(String description) {
                this.description = description;
                return this;
            }

            public NewsArticleBuilder setAuthor(String author) {
                this.author = author;
                return this;
            }

            public NewsArticleBuilder setUrlToImage(String urlToImage) {
                this.urlToImage = urlToImage;
                return this;
            }

            public NewsArticleBuilder setSource(String source) {
                this.source = source;
                return this;
            }

            public NewsArticle build() {
                return new NewsArticle(this);
            }
        }
    }

    // Factory Pattern for creating NewsArticle objects
    public static class NewsArticleFactory {
        public static NewsArticle createArticle(NewsArticleResponse response) {
            if (response.title == null || response.description == null) {
                return null; // Skip invalid articles
            }

            return new NewsArticle.NewsArticleBuilder()
                    .setTitle(response.title)
                    .setDescription(response.description)
                    .setAuthor(response.author != null ? response.author : "Unknown")
                    .setUrlToImage(response.urlToImage)
                    .setSource(response.source != null ? response.source.name : "Unknown")
                    .build();
        }
    }

    // Adapter Pattern for converting ResultSet to User Preferences
    public static class UserPreferencesAdapter {
        private String category;

        public UserPreferencesAdapter(ResultSet resultSet) throws SQLException {
            if (resultSet.next()) {
                this.category = resultSet.getString("Category");
            }
        }

        public String getCategory() {
            return category;
        }
    }

    // Response classes for parsing the JSON response from NewsAPI
    public static class NewsApiResponse {
        private List<NewsArticleResponse> articles;

        public List<NewsArticleResponse> getArticles() {
            return articles;
        }
    }

    public static class NewsArticleResponse {
        private String title;
        private String description;
        private String author;
        private String urlToImage;
        private NewsSource source;

        public String getTitle() {
            return title;
        }

        public String getDescription() {
            return description;
        }

        public String getAuthor() {
            return author;
        }

        public String getUrlToImage() {
            return urlToImage;
        }

        public NewsSource getSource() {
            return source;
        }
    }

    public static class NewsSource {
        private String name;

        public String getName() {
            return name;
        }
    }
}
